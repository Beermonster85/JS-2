// const age = parseInt(prompt('Ваш возраст?', '18'));
// console.log(age);

// const age2 = +prompt('Ваш возраст?', '18');
// console.log(age2);

// console.log(age + age2);

// const name = 'Aleksey';
// alert(`Добро пожаловать на сайт, ${name}`);

// let a = 13;
// let b = 5;

// console.log(a % b);

// let a;
// alert(a);

// alert('abc' * 3);

// alert(1 / 0);
// alert(-1 / 0);

// alert('2' * '3');

// let a = '2';
// let b = '3';

// console.log(a + b);

// const a = +prompt('Введите число 1');
// const b = +prompt('Введите число 2');

// console.log(`
// 	Сумма чисел равна ${a + b}
// 	Разность чисел равна ${a - b}
// 	Произведение чисел равно ${a * b}
// 	Частное чисел равно ${a / b}
// 	Остаток от деления чисел равен ${a % b}
// `);

// console.log(String(true));
// console.log('a' + true);
// console.log(Number(true));
// console.log(true + 1);
// console.log(true + true);
// console.log(true - true);
// console.log(String(true) + Number(true));

// const a = +prompt('Введите число');

// if (a > 5) {
// 	console.log(`Число ${a} больше 5`);
// } else if (a < 5) {
// 	console.log(`Число ${a} меньше 5`);
// } else {
// 	console.log(`Число ${a} равно 5`);
// }

// const test1 = 10;
// const test2 = '10';

// console.log(test1 != test2);

// == - нестрогое равенство
// === - строгое равенство
// != - нестрогое неравенство
// !== - строгое неравенство

// const a = +prompt('Введите число 1');
// const b = +prompt('Введите число 2');

// if (a > b) {
// 	console.log(`Число ${a} больше `);
// } else {
// 	console.log(`Число ${b} больше `);
// }

const a = +prompt('Введите число');

// if (a == 0 || a == 15) {
// 	console.log('OK');
// } else {
// 	console.log(':(');
// }

a >= 15 ? console.log('OK') : console.log(':(');
